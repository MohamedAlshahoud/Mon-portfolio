document.addEventListener("DOMContentLoaded", function(){ window.addEventListener( 'load', function() {
	UAGBCounter.init( '.uagb-block-0a4cb8de', {"layout":"number","heading":"Satisfaction des parents","numberPrefix":"","numberSuffix":"%","startNumber":0,"endNumber":95,"totalNumber":100,"decimalPlaces":0,"animationDuration":1500,"thousandSeparator":",","circleSize":230,"circleStokeSize":8,"isFrontend":true} );
});
window.addEventListener( 'load', function() {
	UAGBCounter.init( '.uagb-block-83c8f8c1', {"layout":"number","heading":"\u00c9l\u00e8ves inscrits","numberPrefix":"","numberSuffix":"+","startNumber":0,"endNumber":200,"totalNumber":1000,"decimalPlaces":0,"animationDuration":1500,"thousandSeparator":",","circleSize":230,"circleStokeSize":8,"isFrontend":true} );
});
window.addEventListener( 'load', function() {
	UAGBCounter.init( '.uagb-block-7ee20442', {"layout":"number","heading":"Ratio \u00e9l\u00e8ves-enseignants","numberPrefix":"","numberSuffix":":1","startNumber":0,"endNumber":12,"totalNumber":100,"decimalPlaces":0,"animationDuration":1500,"thousandSeparator":",","circleSize":230,"circleStokeSize":8,"isFrontend":true} );
});
window.addEventListener( 'load', function() {
	UAGBCounter.init( '.uagb-block-f257fef2', {"layout":"number","heading":"R\u00e9ussite de pr\u00e9paration","numberPrefix":"","numberSuffix":"%","startNumber":0,"endNumber":98,"totalNumber":100,"decimalPlaces":0,"animationDuration":1500,"thousandSeparator":",","circleSize":230,"circleStokeSize":8,"isFrontend":true} );
});
 });
# Security Policy

Thank you for your interest in helping us improve the security of our open source products, websites and other properties.

## How can I report security bugs?

You can report security bugs through the Patchstack Vulnerability Disclosure Program. The Patchstack team helps validate, triage and handle any security vulnerabilities. [Report a security vulnerability.](https://patchstack.com/database/vdp/9e5fbe9d-5d93-420a-8168-1e61d027c71e)
